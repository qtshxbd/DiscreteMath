"""
Minimal graph theory toolkit: adjacency-list graph with BFS, DFS,
connectivity, and cycle detection - the core graph unit of most
discrete math courses.
"""

from collections import deque
from dataclasses import dataclass, field


@dataclass
class Graph:
    directed: bool = False
    adjacency: dict[str, set[str]] = field(default_factory=dict)

    def add_vertex(self, v: str) -> None:
        self.adjacency.setdefault(v, set())

    def add_edge(self, u: str, v: str) -> None:
        self.add_vertex(u)
        self.add_vertex(v)
        self.adjacency[u].add(v)
        if not self.directed:
            self.adjacency[v].add(u)

    def bfs(self, start: str) -> list[str]:
        visited = {start}
        order = []
        queue = deque([start])
        while queue:
            node = queue.popleft()
            order.append(node)
            for neighbor in sorted(self.adjacency.get(node, [])):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        return order

    def dfs(self, start: str) -> list[str]:
        visited = set()
        order = []

        def _visit(node: str) -> None:
            visited.add(node)
            order.append(node)
            for neighbor in sorted(self.adjacency.get(node, [])):
                if neighbor not in visited:
                    _visit(neighbor)

        _visit(start)
        return order

    def is_connected(self) -> bool:
        if not self.adjacency:
            return True
        start = next(iter(self.adjacency))
        return len(self.bfs(start)) == len(self.adjacency)

    def has_cycle(self) -> bool:
        if self.directed:
            return self._has_cycle_directed()
        return self._has_cycle_undirected()

    def _has_cycle_undirected(self) -> bool:
        visited = set()

        def _visit(node: str, parent: str | None) -> bool:
            visited.add(node)
            for neighbor in self.adjacency.get(node, []):
                if neighbor not in visited:
                    if _visit(neighbor, node):
                        return True
                elif neighbor != parent:
                    return True
            return False

        for v in self.adjacency:
            if v not in visited:
                if _visit(v, None):
                    return True
        return False

    def _has_cycle_directed(self) -> bool:
        WHITE, GRAY, BLACK = 0, 1, 2
        color = {v: WHITE for v in self.adjacency}

        def _visit(node: str) -> bool:
            color[node] = GRAY
            for neighbor in self.adjacency.get(node, []):
                if color[neighbor] == GRAY:
                    return True
                if color[neighbor] == WHITE and _visit(neighbor):
                    return True
            color[node] = BLACK
            return False

        return any(color[v] == WHITE and _visit(v) for v in self.adjacency)

    def degree(self, v: str) -> int:
        return len(self.adjacency.get(v, []))


if __name__ == "__main__":
    g = Graph()
    for u, v in [("A", "B"), ("B", "C"), ("C", "D"), ("D", "A")]:
        g.add_edge(u, v)

    print("BFS from A:", g.bfs("A"))
    print("DFS from A:", g.dfs("A"))
    print("Connected:", g.is_connected())
    print("Has cycle:", g.has_cycle())
    print("Degree of A:", g.degree("A"))
