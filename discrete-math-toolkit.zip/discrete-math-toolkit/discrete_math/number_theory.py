"""
Number theory basics: primality, GCD/LCM, and modular arithmetic
(modular exponentiation, modular inverse) - core to Math 55's
number theory unit and to basic cryptography.
"""


def is_prime(n: int) -> bool:
    if n < 2:
        return False
    if n in (2, 3):
        return True
    if n % 2 == 0:
        return False
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def sieve_of_eratosthenes(limit: int) -> list[int]:
    """All primes <= limit."""
    if limit < 2:
        return []
    is_p = [True] * (limit + 1)
    is_p[0] = is_p[1] = False
    for i in range(2, int(limit ** 0.5) + 1):
        if is_p[i]:
            for multiple in range(i * i, limit + 1, i):
                is_p[multiple] = False
    return [i for i, prime in enumerate(is_p) if prime]


def gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return abs(a)


def lcm(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return abs(a * b) // gcd(a, b)


def extended_gcd(a: int, b: int) -> tuple[int, int, int]:
    """Returns (g, x, y) such that a*x + b*y = g = gcd(a, b)."""
    if b == 0:
        return a, 1, 0
    g, x1, y1 = extended_gcd(b, a % b)
    return g, y1, x1 - (a // b) * y1


def mod_inverse(a: int, m: int) -> int | None:
    """Modular multiplicative inverse of a mod m, or None if it doesn't exist."""
    g, x, _ = extended_gcd(a, m)
    if g != 1:
        return None
    return x % m


def mod_pow(base: int, exponent: int, modulus: int) -> int:
    """Fast modular exponentiation: base^exponent mod modulus."""
    return pow(base, exponent, modulus)


if __name__ == "__main__":
    print("Primes up to 50:", sieve_of_eratosthenes(50))
    print("gcd(48, 18) =", gcd(48, 18))
    print("lcm(4, 6) =", lcm(4, 6))
    print("Inverse of 3 mod 11 =", mod_inverse(3, 11))
    print("7^128 mod 13 =", mod_pow(7, 128, 13))
