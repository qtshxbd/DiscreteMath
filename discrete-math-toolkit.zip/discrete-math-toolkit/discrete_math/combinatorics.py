"""
Combinatorics: permutations, combinations, and the pigeonhole/inclusion-exclusion
helpers that show up constantly in Math 55-style discrete math courses.
"""

from itertools import combinations, permutations
from math import comb, factorial


def n_permutations(n: int, r: int) -> int:
    """Number of ways to arrange r items from a set of n, order matters: P(n, r)."""
    if r > n or r < 0:
        return 0
    return factorial(n) // factorial(n - r)


def n_combinations(n: int, r: int) -> int:
    """Number of ways to choose r items from a set of n, order doesn't matter: C(n, r)."""
    return comb(n, r)


def list_permutations(items: list, r: int | None = None) -> list[tuple]:
    """Return all permutations of `items` taken r at a time (default: all)."""
    return list(permutations(items, r))


def list_combinations(items: list, r: int) -> list[tuple]:
    """Return all combinations of `items` taken r at a time."""
    return list(combinations(items, r))


def inclusion_exclusion(set_sizes: list[int], pairwise_intersections: dict[tuple[int, int], int],
                         triple_intersections: dict[tuple[int, int, int], int] | None = None) -> int:
    """
    |A1 ∪ A2 ∪ ... ∪ An| via inclusion-exclusion, up to triple intersections.
    set_sizes: [|A1|, |A2|, ...] (0-indexed)
    pairwise_intersections: {(i, j): |Ai ∩ Aj|}
    triple_intersections: optional {(i, j, k): |Ai ∩ Aj ∩ Ak|}
    """
    total = sum(set_sizes)
    total -= sum(pairwise_intersections.values())
    if triple_intersections:
        total += sum(triple_intersections.values())
    return total


def pigeonhole_min_per_hole(n_items: int, n_holes: int) -> int:
    """Pigeonhole principle: minimum guaranteed items in the fullest hole."""
    if n_holes <= 0:
        raise ValueError("n_holes must be positive")
    return -(-n_items // n_holes)  # ceiling division


if __name__ == "__main__":
    print("P(5, 2) =", n_permutations(5, 2))
    print("C(5, 2) =", n_combinations(5, 2))
    print("Combos of ABCD taken 2 at a time:", list_combinations(list("ABCD"), 2))
    print("Pigeonhole: 25 items, 4 holes -> at least", pigeonhole_min_per_hole(25, 4), "in one hole")
