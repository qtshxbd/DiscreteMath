from discrete_math.combinatorics import n_permutations, n_combinations, pigeonhole_min_per_hole
from discrete_math.graphs import Graph
from discrete_math.number_theory import is_prime, gcd, lcm, mod_inverse, mod_pow, sieve_of_eratosthenes


def test_permutations_and_combinations():
    assert n_permutations(5, 2) == 20
    assert n_combinations(5, 2) == 10


def test_pigeonhole():
    assert pigeonhole_min_per_hole(25, 4) == 7


def test_graph_cycle_detection():
    g = Graph()
    for u, v in [("A", "B"), ("B", "C"), ("C", "D"), ("D", "A")]:
        g.add_edge(u, v)
    assert g.has_cycle() is True
    assert g.is_connected() is True


def test_graph_no_cycle():
    g = Graph()
    for u, v in [("A", "B"), ("B", "C")]:
        g.add_edge(u, v)
    assert g.has_cycle() is False


def test_number_theory():
    assert is_prime(97) is True
    assert is_prime(100) is False
    assert gcd(48, 18) == 6
    assert lcm(4, 6) == 12
    assert mod_inverse(3, 11) == 4
    assert mod_pow(7, 128, 13) == pow(7, 128, 13)
    assert sieve_of_eratosthenes(10) == [2, 3, 5, 7]
